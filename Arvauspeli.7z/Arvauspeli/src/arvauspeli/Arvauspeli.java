package arvauspeli;

public class Arvauspeli {

    public static void main(String[] args) {
        Peli peli = new Peli();
    }
    
}
